
# Get the directory name for data files
import os.path
directory = os.path.dirname(os.path.abspath(__file__))  

#initialize the aggregators
years1=[]
adam_sandler=[]
years2=[]
plane_deaths=[]

# Open the file
filename = os.path.join(directory, 'as.txt')
datafile = open(filename,'r')
for line in datafile:
    year, deaths, movies = line.split(',')
    # Aggregate based on Adam Sandler
    years1 += [year]
    adam_sandler += [movies]
    #Aggregate based on plane crash fatalities
    years2 += [year]
    plane_deaths += [deaths]
#Close file
datafile.close()

# Plot on one set of axes.
import matplotlib.pyplot as plt
# Adam Sandler and plane crashes
fig1, ax1 = plt.subplots(1,1)
ax1.plot(years1,adam_sandler,'#FF0000')
ax1.plot(years2,plane_deaths,'#0000FF')
ax1.set_title('Movies by Adam Sandler(Red) Deaths in plane accidents(Blue)')
fig1.show()
# Adam Sandler movies
fig2, ax2 = plt.subplots(1,1)
ax2.plot(years1,adam_sandler,'#FF0000')
ax2.set_title('Adam sandler movies')
fig2.show()
# Plane crash deaths
fig3, ax3 = plt.subplots(1,1)
ax3.plot(years2,plane_deaths,'#0000FF')
ax3.set_title('Deaths in plane accidents')
fig3.show()
